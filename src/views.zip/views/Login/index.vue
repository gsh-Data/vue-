<template>
  <div id="login">
    <div class="menu">
      <ul class="menu-tab">
        <li
          :class="{'current':isActice==item.current}"
          v-for="(item,index) in menuTab"
          :key="index"
          @click="toggleMenu(item)"
        >{{item.text}}</li>
      </ul>
      <!-- 表单 -->
      <el-form
        :model="ruleForm"
        status-icon
        :rules="rules"
        ref="ruleForm"
        label-position="top"
        class="login-ruleForm"
        size="medium"
      >
        <el-form-item label="邮箱" prop="userName">
          <el-input v-model="ruleForm.userName" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            type="text"
            v-model="ruleForm.password"
            autocomplete="off"
            maxlength="20"
            minlength="6"
          ></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="affirm" v-show="model=='register'">
          <el-input
            type="text"
            v-model="ruleForm.affirm"
            autocomplete="off"
            maxlength="20"
            minlength="6"
          ></el-input>
        </el-form-item>
        <el-form-item label="验证码" prop="verification">
          <el-row :gutter="20">
            <el-col :span="16">
              <div class="grid-content bg-purple">
                <el-input v-model.number="ruleForm.verification" maxlength="6" minlength="6"></el-input>
              </div>
            </el-col>
            <el-col :span="8">
              <el-button type="success" class="block">验证码</el-button>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item>
          <el-button type="danger" class="block" @click="submitForm('ruleForm')">{{menuTab[0].text}}</el-button>
          
        </el-form-item>
      </el-form>
    </div>
    
  </div>
</template>
<script>
import { stripscript } from "@/utils/validata.js";
import { code } from "../../api/index";
export default {
  name: "login",
  data() {
    //邮箱
    var validateUserName = (rule, value, callback) => {
      let reg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/; // eslint-disable-line no-unused-vars
      if (value === "") {
        callback(new Error("请输入邮箱"));
      } else if (!reg.test(value)) {
        callback(new Error("请输入邮箱格式有误"));
      } else {
        callback();
      }
    };
    //密码
    var validatePassword = (rule, value, callback) => {
      this.ruleForm.password = stripscript(value);
      value = this.ruleForm.password;
      let reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$/; // eslint-disable-line no-unused-vars
      if (value === "") {
        callback(new Error("请输入密码"));
      } else if (!reg.test(value)) {
        callback(new Error("密码至少包含 数字和英文不能输入特殊字符"));
      } else {
        callback();
      }
    };
    var validateAffirm = (rule, value, callback) => {
      this.ruleForm.affirm = stripscript(value);
      value = this.ruleForm.affirm;
      let reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$/; // eslint-disable-line no-unused-vars
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (!reg.test(value)) {
        callback(new Error("密码至少包含 数字和英文不能输入特殊字符"));
      } else if (!(this.ruleForm.password == this.ruleForm.affirm)) {
        callback(new Error("密码不一致"));
      } else {
        callback();
      }
    };
    //验证码
    var validateverification = (rule, value, callback) => {
      this.ruleForm.verification = stripscript(value);
      value = this.ruleForm.verification;
      let reg = /^[a-z0-9]{6}$/; // eslint-disable-line no-unused-vars
      if (!value) {
        return callback(new Error("验证码不能为空"));
      } else if (!reg.test(value)) {
        return callback(new Error("验证码格式有误"));
      } else {
        callback();
      }
    };
    return {
      menuTab: [
        { text: "登录", current: true, type: "login" },
        { text: "注册", current: false, type: "register" }
      ],
      isActice: true,
      ruleForm: {
        userName: "",
        password: "",
        affirm: "",
        verification: ""
      },
      model: "login",
      rules: {
        userName: [{ validator: validateUserName, trigger: "blur" }],
        password: [{ validator: validatePassword, trigger: "blur" }],
        affirm: [{ validator: validateAffirm, trigger: "blur" }],
        verification: [{ validator: validateverification, trigger: "blur" }]
      }
    };
  },
  methods: {
    toggleMenu(data) {
      this.menuTab.forEach(elem => {
        elem.current = false;
      });
      this.model = data.type;
      data.current = true;
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        console.log(valid);
        if (!valid) {
          alert("submit!");
          console.log("登录成功");
          this.$router.push({
            name: "Console"
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    }
  },
  mounted() {
    //  console.log(process.env.NODE_ENV)
    // code();
  }
};
</script>
<style lang="scss" scoped>
#login {
  background: #344a5f;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  .menu {
    width: 330px;
    height: 330;
    .menu-tab {
      text-align: center;
      li {
        font-size: 14px;
        color: #fff;
        width: 88px;
        line-height: 36px;
        display: inline-block;
        border-radius: 2px;
        cursor: pointer;
      }
      .current {
        background: rgba(000, 000, 000, 0.1);
      }
    }
    .login-ruleForm {
      /deep/ .el-form-item__label {
        color: #fff;
      }
      .block {
        display: block;
        width: 100%;
      }
    }
  }
}
</style>