<template>
    <div>业务信息</div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>
    
</style>